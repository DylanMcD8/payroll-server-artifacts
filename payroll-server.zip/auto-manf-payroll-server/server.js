import { connect, closeClient } from './src/swen343_db_utils.js';
import { initializeDatabase } from './src/databaseSetup.js';
import application from './src/app.js';

// Get the process port
const port = Number(process.env.PORT ?? 5005);

try {
	// Verify port
	if (!Number.isInteger(port) || port < 1 || port > 65535) {
		throw new Error('PORT must be an integer between 1 and 65535');
	}

	// Connect, initialize, and ensure the collection exists
	await connect();
	await initializeDatabase();
	const server = application.listen(port, () => {
		console.log(`Payroll API setup and now listening on port ${port}!`);
	});

	// Handle errors
	server.on('error', async (error) => {
		console.error('Unable to start HTTP server:', error);
		await closeClient();
		process.exitCode = 1;
	});

	// Shut down server
	function shutdown() {
		server.close(async () => {
			await closeClient();
		});
	}

	process.once('SIGINT', shutdown); // ⌃-C in terminal
	process.once('SIGTERM', shutdown); // Standard "stop" request

	// Catch errors
} catch (error) {
	console.error('Unable to start payroll server:', error);
	await closeClient();
	process.exitCode = 1;
}
