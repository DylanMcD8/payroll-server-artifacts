import express from 'express';
import {
    getCollections, getAllEmployees, countEmployees, getEmployee,
    addEmployee, replaceEmployee, updateEmployee, deleteEmployee, deactivateEmployee
} from '../api.js';
import { badRequest, buildEmployee, parseId, convertEmployeeToJSONFormat, validateFields } from '../payrollValidation.js';
import { parseQuery } from '../payrollQuery.js';
import { resetDatabase } from '../databaseSetup.js';
import { loadPayroll } from '../loadPayroll.js';

const router = express.Router();

router.post('/admin/reset', async (request, response) => {
    const result = await resetDatabase();
    response.json({ deletedCount: result.deletedCount });
});

router.post('/admin/seed', async (request, response) => {
    const result = await loadPayroll();
    response.json(result);
});

// GET collection names
router.get('/collections', async (request, response) => {
    const collections = await getCollections();
    response.json({
        collections: collections.map(collection => {
            return collection.name;
        })
    });
});

// GET a filtered list of employees
router.get('/employees', async (request, response) => {
    const { filter, page, pageSize, skip, sort } = parseQuery(request.query);
    const [employees, total] = await Promise.all([
        getAllEmployees(filter, pageSize, { skip, sort }), countEmployees(filter)
    ]);
    response.json({
        count: employees.length,
        total,
        page,
        pageSize,
        totalPages: Math.ceil(total / pageSize),
        employees: employees.map(convertEmployeeToJSONFormat)
    });
});

// GET the count of a filtered list of employees
router.get('/employees/count', async (request, response) => {
    const { filter } = parseQuery(request.query);
    const count = await countEmployees(filter);
    response.json({
        count
    });
});

// GET a specific employee
// :id just takes what's there, without ? parameter/format
router.get('/employees/:id', async (request, response) => {
    const employee = await getEmployee(parseId(request.params.id));
    if (!employee) {
        return response.status(404).json({
            error: 'Employee not found'
        });
    }
    response.json(convertEmployeeToJSONFormat(employee));
});

// POST a new employee
router.post('/employees', async (request, response) => {
    const employee = buildEmployee(request.body);
    const result = await addEmployee(employee);
    const employeeId = result.insertedId.toHexString();
    response.location(`${request.baseUrl}/employees/${employeeId}`).status(201).json({
        // 201 = created
        id: employeeId,
        message: 'Payroll employee was successfully created!'
    });
});

// PUT replace an entire employee (all data required)
router.put('/employees/:id', async (request, response) => {
    const employeeObjectId = parseId(request.params.id);
    validateFields(request.body);
    const existing = await getEmployee(employeeObjectId);
    if (!existing) return response.status(404).json({ error: 'Employee not found' });
    const employee = buildEmployee({ ...request.body, active: request.body.active === undefined ? existing.active : request.body.active });
    const result = await replaceEmployee(employeeObjectId, employee);
    if (result.matchedCount === 0) {
        return response.status(404).json({
            error: 'Employee not found'
        });
    }
    response.json({
        id: employeeObjectId.toHexString(),
        message: 'Payroll employee was successfully replaced!'
    });
});

// PATCH certain field(s) of an employee
router.patch('/employees/:id', async (request, response) => {
    // Get the incoming data
    const employeeObjectId = parseId(request.params.id);
    const incomingPatchData = request.body;
    validateFields(incomingPatchData);
    
    // Reject empty requests
    const hasChanges = Object.entries(incomingPatchData).some(([key, value]) => {
        return key === 'state' || key === 'active' || Object.keys(value).length > 0;
    });
    if (!hasChanges) {
        badRequest('Provide at least one field to update');
    }
    
    const existing = await getEmployee(employeeObjectId);
    if (!existing) {
        return response.status(404).json({
            error: 'Employee not found'
        });
    }
    const currentData = convertEmployeeToJSONFormat(existing);
    const employeeId = currentData.id;
    
    // ID is not editable!
    delete currentData.id;
    
    // Set the updated data.....
    if (incomingPatchData.active !== undefined) {
        currentData.active = incomingPatchData.active;
    }
    if (incomingPatchData.state !== undefined) {
        currentData.state = incomingPatchData.state;
    }
    
    if (incomingPatchData.name !== undefined) {
        if (incomingPatchData.name.first !== undefined) {
            currentData.name.first = incomingPatchData.name.first;
        }
        
        if (incomingPatchData.name.last !== undefined) {
            currentData.name.last = incomingPatchData.name.last;
        }
    }
    
    if (incomingPatchData.compensation !== undefined) {
        if (incomingPatchData.compensation.payRate !== undefined) {
            currentData.compensation.payRate = incomingPatchData.compensation.payRate;
        }
        
        if (incomingPatchData.compensation.classification !== undefined) {
            currentData.compensation.classification = incomingPatchData.compensation.classification;
        }
        
        if (incomingPatchData.compensation.grossPay !== undefined) {
            currentData.compensation.grossPay = incomingPatchData.compensation.grossPay;
        }
    }
    
    if (incomingPatchData.payment !== undefined) {
        if (incomingPatchData.payment.method !== undefined) {
            currentData.payment.method = incomingPatchData.payment.method;
        }
        
        if (incomingPatchData.payment.bankRoutingNumber !== undefined) {
            currentData.payment.bankRoutingNumber = incomingPatchData.payment.bankRoutingNumber;
        }
    }
    
    
    // Validate the combined data and put it all back into a mongo employee object
    const updatedEmployee = buildEmployee(currentData);
    
    // Save the fields!
    const update = {
        $set: {
            active: updatedEmployee.active,
            name: updatedEmployee.name,
            state: updatedEmployee.state,
            compensation: updatedEmployee.compensation,
            payment: updatedEmployee.payment
        }
    };
    
    // Send the update
    const result = await updateEmployee(employeeObjectId, update);
    if (result.matchedCount === 0) {
        return response.status(404).json({
            error: 'Employee not found'
        });
    }
    
    // Respond
    response.json({
        id: employeeId,
        message: 'Payroll employee was successfully updated!'
    });
});

// DELETE If an active employee, mark inactive. If inactive, fully delete.
router.delete('/employees/:id', async (request, response) => {
    for (const key of Object.keys(request.query)) {
        if (key !== 'permanent') badRequest(`Invalid query parameter: ${key}`);
    }
    const permanent = request.query.permanent ?? 'false';
    if (!['true', 'false'].includes(permanent)) badRequest('permanent must be true or false');
    const id = parseId(request.params.id);
    if (permanent === 'false') {
        const result = await deactivateEmployee(id);
        if (!result.matchedCount) return response.status(404).json({ error: 'Employee not found' });
        return response.status(204).end();
    }
    
    const result = await deleteEmployee(id);
    if (result.deletedCount) return response.status(204).end();
    const existing = await getEmployee(id);
    if (!existing) return response.status(404).json({ error: 'Employee not found' });
    return response.status(409).json({ error: 'Deactivate the employee before permanently deleting them' });
});

export default router;
