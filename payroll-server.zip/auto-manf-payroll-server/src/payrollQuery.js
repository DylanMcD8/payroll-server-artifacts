import { badRequest, classifications, money, paymentMethods } from './payrollValidation.js';

// Convert URL fields into mongo fields
const fields = {
    firstName: 'name.first',
    lastName: 'name.last',
    state: 'state',
    payRate: 'compensation.payRate',
    classification: 'compensation.classification',
    grossPay: 'compensation.grossPay',
    depositMethod: 'payment.method',
    bankRoutingNumber: 'payment.bankRoutingNumber',
    active: 'active'
};

// Create a positive int from a string (aka convert URL param to mongo value)
function positiveInteger(value, maximum) {
    if (!/^\d+$/.test(value) || !Number.isSafeInteger(Number(value)) ||
        Number(value) < 1 || Number(value) > maximum) {
        badRequest(`Value must be an integer between 1 and ${maximum}`);
    }
    return Number(value);
}

// Create a valid money value from a string (aka convert URL param to mongo value)
function amount(value) {
    if (!/^\d+(\.\d{1,2})?$/.test(value)) {
        badRequest('Invalid amount');
    }
    return money(Number(value));
}

// Convert URL params / query into options/info to use wtih mongo
export function parseQuery(query) {
    // The allowed parameters
    const allowed = new Set([
        ...Object.keys(fields), 'minPayRate', 'maxPayRate', 'minGrossPay', 'maxGrossPay',
        'page', 'pageSize', 'resultLimit', 'sortBy', 'sortOrder', 'search'
    ]);

    // Get the param name and value, and ensure it's valid
    for (const [key, value] of Object.entries(query)) {
        if (!allowed.has(key) || typeof value !== 'string') {
            badRequest(`Invalid query parameter: ${key}`);
        }
        if (!value.trim()) {
            badRequest(`${key} cannot be empty`);
        }
    }

    // Setup filters...
    const filter = {};

    if (query.search !== undefined) {
        const search = query.search.trim();
        const escaped = search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const searchFields = ['name.first', 'name.last', 'state', 'compensation.classification', 'payment.bankRoutingNumber'];
        filter.$or = searchFields.map(field => ({
            [field]: { $regex: escaped, $options: 'i' }
        }));
        filter.$or.push({
            $expr: {
                $regexMatch: {
                    input: { $concat: ['$name.first', ' ', '$name.last'] },
                    regex: escaped,
                    options: 'i'
                }
            }
        });
        filter.$or.push({
            'payment.method': {
                $regex: search.replaceAll(' ', '_').replace(/[.*+?^${}()|[\]\\]/g, '\\$&'),
                $options: 'i'
            }
        });
        const numericSearch = search.replace(/[$,]/g, '');
        if (/^\d+(\.\d{1,2})?$/.test(numericSearch)) {
            const escapedAmount = numericSearch.replace('.', '\\.');
            for (const field of ['compensation.payRate', 'compensation.grossPay']) {
                filter.$or.push({ [field]: amount(numericSearch) });
                filter.$or.push({
                    $expr: { $regexMatch: { input: { $toString: `$${field}` }, regex: escapedAmount } }
                });
            }
        }
    }
    
    // Default to only showing active employees
    let active = 'true';
    if (query.active !== undefined) {
        active = query.active;
    }
    // Convert active param to bool for mongo
    if (active === 'true') {
        filter.active = true;
    } else if (active === 'false') {
        filter.active = false;
    } else if (active === 'all') {
        // Not filtering by active
    } else {
        badRequest('active must be true, false, or all');
    }

    // Add the requested filters
    for (const parameter of ['firstName', 'lastName', 'state']) {
        if (query[parameter] !== undefined) {
            // Escape regex punctuation
            const escaped = query[parameter].trim().replace(/[.*+?^${}()|\[\]\\]/g, '\\$&');
            
            filter[fields[parameter]] = {
                $regex: `^${escaped}$`,
                $options: 'i'
            };
        }
    }
    
    for (const [parameter, choices] of [['classification', classifications], ['depositMethod', paymentMethods]]) {
        if (query[parameter] !== undefined) {
            if (!choices.includes(query[parameter])) {
                badRequest(`Invalid ${parameter}`);
            }
            filter[fields[parameter]] = query[parameter];
        }
    }
    
    // Routing number
    if (query.bankRoutingNumber !== undefined) {
        // none param = no routing number field
        if (query.bankRoutingNumber === 'none') {
            filter[fields.bankRoutingNumber] = { $exists: false };
        } else {
            if (!/^\d{9}$/.test(query.bankRoutingNumber)) {
                badRequest('Routing number must be 9 digits or "none".');
            }
            filter[fields.bankRoutingNumber] = query.bankRoutingNumber;
        }
    }
    
    // Pay / rate stuff
    for (const [parameter, minimum, maximum, label] of [
        ['payRate', 'minPayRate', 'maxPayRate', 'pay rate'],
        ['grossPay', 'minGrossPay', 'maxGrossPay', 'gross pay']
    ]) {
        
        // Needs to be an amount or a range
        if (query[parameter] !== undefined && (query[minimum] !== undefined || query[maximum] !== undefined)) {
            badRequest(`Use ${parameter} or its range, not both`);
        }
        if (query[parameter] !== undefined) {
            filter[fields[parameter]] = amount(query[parameter]);
        }

        const range = {};
        if (query[minimum] !== undefined) {
            range.$gte = amount(query[minimum]);
            // gte = greater than or equal to
        }
        if (query[maximum] !== undefined) {
            range.$lte = amount(query[maximum]);
            // lte = less than or equal to
        }
        if (query[minimum] !== undefined && query[maximum] !== undefined && Number(query[minimum]) > Number(query[maximum])) {
            badRequest(`Minimum ${label} cannot exceed maximum ${label}.`);
        }
        
        if (Object.keys(range).length) {
            filter[fields[parameter]] = range;
        }
    }

    // Gotta choose either a page size or a limited number of results (or none)
    if (query.pageSize !== undefined && query.resultLimit !== undefined) {
        badRequest('Use pageSize or resultLimit, not both');
    }
    
    let requestedPageSize = '25';
    if (query.pageSize !== undefined) {
        requestedPageSize = query.pageSize;
    } else if (query.resultLimit !== undefined) {
        requestedPageSize = query.resultLimit;
    }
    const pageSize = positiveInteger(requestedPageSize, 1000);

    let requestedPage = '1';
    if (query.page !== undefined) {
        requestedPage = query.page;
    }
    const page = positiveInteger(requestedPage, Number.MAX_SAFE_INTEGER);
    // Claculate skip based on page number
    const skip = (page - 1) * pageSize;
    if (!Number.isSafeInteger(skip)) {
        badRequest('Requested page is too large');
    }
    
    // Validate and set sorting
    let sortBy = 'lastName';
    if (query.sortBy !== undefined) {
        sortBy = query.sortBy;
    }
    if (!Object.hasOwn(fields, sortBy)) {
        badRequest('Invalid sortBy');
    }
    let sortOrder = 'asc';
    if (query.sortOrder !== undefined) {
        sortOrder = query.sortOrder;
    }
    if (!['asc', 'desc'].includes(sortOrder)) {
        badRequest('sortOrder must be asc or desc');
    }
    
    // 1 = ascending, -1 = descending
    let sortDirection = 1;
    if (sortOrder === 'desc') {
        sortDirection = -1;
    }

    const sort = {};
    const databaseField = fields[sortBy];
    sort[databaseField] = sortDirection;
    if (sortBy === 'lastName') {
        sort['name.first'] = sortDirection;
    }
    
    sort._id = 1; 
    
    return {
        filter,
        page,
        pageSize,
        skip,
        sort
    };
}
