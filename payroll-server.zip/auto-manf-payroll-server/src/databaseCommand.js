import { connect, closeClient } from './swen343_db_utils.js';
import { initializeDatabase, resetDatabase } from './databaseSetup.js';
import { loadPayroll } from './loadPayroll.js';

// Interface for initializing / adding default data to / resetting the database

const command = process.argv[2];
if (!['init', 'addDefaults', 'reset'].includes(command) || process.argv.length !== 3) {
    console.error('Usage: node src/databaseCommand.js <init|addDefaults|reset>');
    process.exitCode = 1;
} else {
    try {
        await connect();
        if (command === 'init') {
            await initializeDatabase();
            console.log('Payroll database initialized; existing records preserved.');
        } else if (command === 'addDefaults') {
            await loadPayroll();
        } else {
            const result = await resetDatabase();
            console.log(`Payroll database reset: removed ${result.deletedCount} employees.`);
        }
    } catch (error) {
        console.error(`Database ${command} failed:`, error);
        process.exitCode = 1;
    } finally {
        await closeClient();
    }
}
