import { EMPLOYEE_COLLECTION, getDatabase, getEmployees } from './swen343_db_utils.js';

// BASIC DATABSE FUNCTIONS

// List collections owned by the payroll dept
export async function getCollections() {
	return getDatabase().listCollections({
		name: EMPLOYEE_COLLECTION
	}).toArray(); // convert cursor into array
}

// Get all employees from database
// Empty filter = every employee, or supply a field
export async function getAllEmployees(filter = {}, limit, { sort, skip = 0 } = {}) {
	const collection = getEmployees();
	const employees = collection.find(filter)
	.sort(sort ?? { 'name.last': 1, 'name.first': 1, _id: 1 }) // Default is last name, then first name, then unique ID for tiebreaker
	.skip(skip); // For pagination, skip first ## of items

	// Apply a results limit if specified
	if (limit !== undefined) {
		employees.limit(limit);
	}

	return employees.toArray(); // convert cursor into array
}

// Get a count of all employees
export async function countEmployees(filter = {}) {
	return getEmployees().countDocuments(filter);
}

// Get one employee for a given ID
export async function getEmployee(employeeId) {
	return getEmployees().findOne({
		_id: employeeId
	});
}

// Add an employee
export async function addEmployee(employeeData) {
	const collection = getEmployees();
	return collection.insertOne(employeeData); // returns insertedId
}

// Replace all of the data for a given employee (replaces the document)
export async function replaceEmployee(employeeId, employeeData) {
	return getEmployees().replaceOne({
		_id: employeeId
	}, employeeData);
}

// Update data for an employee
export async function updateEmployee(employeeId, updateDocument) {
	const collection = getEmployees();
	const filter = {
		_id: employeeId
	};
	return collection.updateOne(filter, updateDocument);
}

// Mark an employee as inactive
export async function deactivateEmployee(employeeId) {
	return getEmployees().updateOne({ _id: employeeId }, { $set: { active: false } });
}

// Delete an employee ONLY if it's inactive.
export async function deleteEmployee(employeeId) {
	return getEmployees().deleteOne({ _id: employeeId, active: false });
}

export async function getMyCollection() {
	return getDatabase().collection('mycollection').find({}).toArray();
}
