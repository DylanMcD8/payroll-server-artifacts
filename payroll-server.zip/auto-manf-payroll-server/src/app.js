import express from 'express';
import cors from 'cors';
import payrollRouter from './routes/payroll.js';

// Create the "application"
const application = express();

application.use(cors());

// Parse JSON request bodies
application.use(express.json());

// A simple little test just to make sure the server is running / repsonding correctly
application.get('/ping', (request, response) => {
	return response.send('pong! 🏓');
});

application.use('/api/v1/payroll', payrollRouter);

// If no earlier router handled the request, we've got a 404
application.use((request, response) => {
	return response.status(404).json({
		error: 'Route not found'
	});
});

// Handle rejected route handlers
application.use((error, request, response, nextHandler) => {
	// Once a response has started, let Express handle the remaining error
	if (response.headersSent) {
		return nextHandler(error);
	}

	if (error.code === 11000) {
		return response.status(409).json({
			error: 'Duplicate entry: an employee with the same first name, last name, state, and gross pay already exists.'
		});
	}

	// Use the code if it's known, otherwise, default to 500 (Internal Sever Error)
	const hasValidStatus = Number.isInteger(error.status) &&
		error.status >= 400 && error.status <= 599;
	let status = 500;
	if (hasValidStatus) {
		status = error.status;
	}

	if (status >= 500) {
		console.error(error);
	}

	return response.status(status).json({
		error: status >= 500
			? 'An unexpected server error occurred'
			: error.message
	});
});

export default application;
