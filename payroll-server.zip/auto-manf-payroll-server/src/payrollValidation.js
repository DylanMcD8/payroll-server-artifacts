import { Decimal128, ObjectId } from 'mongodb';

// For consistency, the allowed values for these fields
export const classifications = ['hourly', 'weekly', 'monthly'];
export const paymentMethods = ['direct_deposit', 'check'];

// Send server error
export function badRequest(message) {
	const error = new Error(message);
	error.status = 400;
	throw error;
}

// Validate and convert the given ID string into a mongo ObjectId
export function parseId(value) {
	if (!/^[a-fA-F0-9]{24}$/.test(value)) {
		badRequest('Invalid employee ID');
	}
	return new ObjectId(value);
}

// Nested sections must be objects, rather than null, arrays, or scalar values.
function requireObject(value) {
	if (value === null || typeof value !== 'object' || Array.isArray(value)) {
		badRequest('Expected an object');
	}
}

// Reject any unexpected keys
function allowFields(object, allowed) {
	requireObject(object);
	for (const field of Object.keys(object)) {
		if (!allowed.includes(field)) {
			badRequest(`Unknown field: ${field}`);
		}
	}
}

// Validate and cleanup general text
function validateAndCleanText(value) {
	if (typeof value !== 'string' || !value.trim()) {
		badRequest('A nonempty text value is required');
	}
	return value.trim();
}

// Validate and convert money strings into proper Decimal128 for mongo
export function money(value) {
	if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 ||
		!/^\d+(\.\d{1,2})?$/.test(String(value))) {
		badRequest('Amount must be a nonnegative number with at most 2 decimals');
	}
	return Decimal128.fromString(String(value));
}

// Validate against unexpected fields
export function validateFields(body) {
	// Flexible fields
	allowFields(body, ['name', 'state', 'compensation', 'payment', 'active']);
	if (Object.hasOwn(body, 'name')) {
		allowFields(body.name, ['first', 'last']);
	}
	if (Object.hasOwn(body, 'compensation')) {
		allowFields(body.compensation, ['payRate', 'classification', 'grossPay']);
	}
	if (Object.hasOwn(body, 'payment')) {
		allowFields(body.payment, ['method', 'bankRoutingNumber']);
	}
}

// What the name says
function validateRoutingNumber(routingNumber) {
	if (
		typeof routingNumber !== 'string' ||
		!/^\d{9}$/.test(routingNumber)
		) {
			badRequest('Direct deposit requires a 9-digit routing number');
		}

	return routingNumber;
}

// Create an employee!
export function buildEmployee(body) {
	// Validate all the data...
	validateFields(body);
	requireObject(body.name);
	requireObject(body.compensation);
	requireObject(body.payment);

	const classification = body.compensation.classification;
	const method = body.payment.method;
	if (!classifications.includes(classification)) {
		badRequest('Invalid compensation.classification');
	}
	if (!paymentMethods.includes(method)) {
		badRequest('Invalid payment.method');
	}

	const payment = {
		method
	};
	if (method === 'direct_deposit') {
		payment.bankRoutingNumber = validateRoutingNumber(body.payment.bankRoutingNumber);
	}

	if (body.active !== undefined && typeof body.active !== 'boolean') {
		badRequest('active must be a boolean');
	}

	// Put it all together
	return {
		active: body.active ?? true,
		name: {
			first: validateAndCleanText(body.name.first),
			last: validateAndCleanText(body.name.last)
		},
		state: validateAndCleanText(body.state),
		compensation: {
			payRate: money(body.compensation.payRate),
			classification,
			grossPay: money(body.compensation.grossPay)
		},
		payment
	};
}

// Convert and employee to JSON shape
export function convertEmployeeToJSONFormat(employee) {
	return {
		// Expose MongoDB _id using the public API field name id.
		id: employee._id.toHexString(),
		active: employee.active,
		name: employee.name,
		state: employee.state,
		compensation: {
			// Match the API spec with JSON numbers; decimal storage stays in MongoDB.
			payRate: Number(employee.compensation.payRate.toString()),
			classification: employee.compensation.classification,
			grossPay: Number(employee.compensation.grossPay.toString())
		},
		payment: employee.payment
	};
}
