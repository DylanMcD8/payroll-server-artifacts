import { getEmployees } from './swen343_db_utils.js';

export const identityCollation = { locale: 'en', strength: 2 };


export async function initializeDatabase() {
    await getEmployees().createIndex(
        { 'name.first': 1, 'name.last': 1, state: 1, 'compensation.grossPay': 1 },
        { name: 'unique_payroll_identity', unique: true, collation: identityCollation }
    );
}

export async function resetDatabase() {
    const result = await getEmployees().deleteMany({});
    await initializeDatabase();
    return result;
}
