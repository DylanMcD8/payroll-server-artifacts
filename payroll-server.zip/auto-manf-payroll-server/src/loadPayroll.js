import { readFile } from 'node:fs/promises';
import { parse } from 'csv-parse/sync';
import { getEmployees } from './swen343_db_utils.js';
import { buildEmployee } from './payrollValidation.js';

import { initializeDatabase, identityCollation } from './databaseSetup.js';

// "Identidty" for an employee (used for preventing duplicates)
function identity(employee) {
	return {
		'name.first': employee.name.first,
		'name.last': employee.name.last,
		state: employee.state,
		'compensation.grossPay': employee.compensation.grossPay
	};
}

// Load the default data
export async function loadPayroll() {
	await initializeDatabase();
	const employees = getEmployees();

	// Get the contents
	const payrollFileUrl = new URL('../../autopayroll.csv', import.meta.url);
	const csvContents = await readFile(payrollFileUrl, 'utf8');
	const rows = parse(csvContents, {
		columns: true,
		skip_empty_lines: true,
		trim: true,
		bom: true
	});

	// Convert CSV rows to mongo document fields
	const paymentMethodMapping = new Map([
		['direct deposit', 'direct_deposit'],
		['cheque', 'check']
	]);

	// Validate the row before inserting
	const documents = rows.map((row, index) => {
		try {
			// Make sure it's a valid number
			for (const field of ['pay_rate', 'gross_pay']) {
				if (!/^\d+(\.\d{1,2})?$/.test(row[field] ?? '')) {
					throw new Error(`Invalid ${field}`);
				}
			}

			// Make the employee!
			return buildEmployee({
				name: {
					first: row.first_name,
					last: row.last_name
				},
				state: row.state,
				compensation: {
					payRate: Number(row.pay_rate),
					classification: row.classification,
					grossPay: Number(row.gross_pay)
				},
				payment: {
					method: paymentMethodMapping.get(row.deposit_method),
					bankRoutingNumber: row.bank_routing_number
				}
			});
		} catch (error) {
			// + 2 to account for zero based array and then the header row
			throw new Error(`CSV row ${index + 2}: ${error.message}`, {
				cause: error
			});
		}
	});

	// Add the new employees!
	let insertedCount = 0;
	let initializedCount = 0;
	for (const employee of documents) {
		const filter = identity(employee);
		try {
			const result = await employees.updateOne(filter, { $setOnInsert: employee }, {
				upsert: true, collation: identityCollation
			});
			insertedCount += result.upsertedCount;
		} catch (error) {
			// Ignore duplicate errors, as not adding the duplicate already "handles" the error as needed
			if (error.code !== 11000 || !await employees.findOne(filter, { collation: identityCollation })) {
				throw error;
			}
		}
		const statusResult = await employees.updateOne(
			{ ...filter, active: { $exists: false } },
			{ $set: { active: true } },
			{ collation: identityCollation }
		);
		initializedCount += statusResult.modifiedCount;
	}
	console.log(`Processed payroll defaults from ${documents.length} CSV records.`);
	return { insertedCount, existingCount: documents.length - insertedCount, initializedCount };
}
