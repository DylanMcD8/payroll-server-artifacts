// Share one MongoDB client and its connection pool across the backend
import { MongoClient } from 'mongodb';
import { config } from 'dotenv';
import { fileURLToPath } from 'node:url';

// Resolve .env relative to this module and make settings available through process.env
config({
	path: fileURLToPath(new URL('../.env', import.meta.url))
});

// Cleanup input
const username = encodeURIComponent(process.env.DB_USER);
const password = encodeURIComponent(process.env.DB_PWD);
// Connect to a database
let connectionString =
`mongodb://${username}:${password}@${process.env.URL}/${process.env.DBNAME}`;

// GitLab CI creates its temporary MongoDB user in the admin database.
// Local installations can omit DB_AUTH_SOURCE and keep the original connection format.
if (process.env.DB_AUTH_SOURCE) {
	const authenticationDatabase = encodeURIComponent(process.env.DB_AUTH_SOURCE);
	connectionString += `?authSource=${authenticationDatabase}`;
}

// Start the client
const client = new MongoClient(connectionString);

export const EMPLOYEE_COLLECTION = 'payrollEmployees';

// Establish connection
export async function connect() {
	await client.connect();
	return getDatabase();
}

// Get the database
export function getDatabase() {
	return client.db(process.env.DBNAME);
}

// Get the collection
export function getEmployees() {
	return getDatabase().collection(EMPLOYEE_COLLECTION);
}

// Close the client
export async function closeClient() {
	await client.close();
}
